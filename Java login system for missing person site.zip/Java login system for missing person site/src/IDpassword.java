import java.util.HashMap;

public class IDpassword {

    HashMap<String,String> logininfo=new HashMap<String, String>();

    IDpassword(){

        logininfo.put("A","A");
        logininfo.put("","");

    }
     protected HashMap getLogininfo(){
        return logininfo;
    }
}
