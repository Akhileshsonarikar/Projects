import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.WeakHashMap;

public class LoginPage implements ActionListener {
    JFrame frame=new JFrame();
    JButton login=new JButton("Login");
    JButton reset=new JButton("Reset");
    JTextField UserIdField=new JTextField();
    JPasswordField Userpassword = new JPasswordField();
    JLabel userId=new JLabel("Username");
    JLabel Userpass=new JLabel("Password");


    HashMap<String,String> logininfo=new HashMap<String,String>();

    LoginPage(HashMap<String,String> loginInfoOriginal){
               logininfo=loginInfoOriginal;

               userId.setBounds(50,100,75,25);
               Userpass.setBounds(50,150,75,25);
               UserIdField.setBounds(150,100,200,25);
               Userpassword.setBounds(150,150,200,25);
               login.setBounds(125,200,100,25);
               login.addActionListener(this);
               login.setFocusable(false);

               reset.setBounds(225,200,100,25);
               reset.addActionListener(this);
               reset.setFocusable(false);
               frame.add(login);
               frame.add(reset);
               frame.add(UserIdField);
               frame.add(Userpassword);
               frame.add(Userpass);
               frame.add(userId);
               frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame.setSize(400,400);
               frame.setLayout(null);
               frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==reset){
            UserIdField.setText("");
            Userpassword.setText("");
        }
        if (e.getSource()==login){

            String userID=UserIdField.getText();
            String password=String.valueOf(Userpassword.getPassword());
            if(logininfo.containsKey(userID)){
                if (logininfo.get(userID).equals(password)){
                     LocalPage welcomePage=new LocalPage();
                     frame.dispose();
                }
            }
        }
    }
}
