import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LocalPage implements ActionListener {
    JFrame frame=new JFrame();
    JLabel Enter = new JLabel("Enter Missing Person's Information");
   JLabel Name=new JLabel("Name:");
   JLabel Address=new JLabel("Address:");
   JLabel Marital= new JLabel("Marital Status:");
   JLabel Gender = new JLabel("Gender:");
   JLabel Age =new JLabel("Age:");
   JLabel Skin=new JLabel("Skin Color:");
   JLabel Height =new JLabel("Height(In cm):");
   JLabel Last = new JLabel("Last Seen:");
   JTextField name=new JTextField();
   JTextField address=new JTextField();
   JCheckBox Single = new JCheckBox("Single");
   JCheckBox Married= new JCheckBox("Married");
   JCheckBox Male=new JCheckBox("Male");
   JCheckBox Female=new JCheckBox("Female");
   JTextField age=new JTextField();
   JTextField skin = new JTextField();
   JTextField height=new JTextField();
   JTextField last=new JTextField();
   JLabel Relative=new JLabel("Relative's Name:");
   JLabel Contact=new JLabel("Relative's Contact Number:");
   JTextField relative=new JTextField();
   JTextField contact=new JTextField();
   JButton Upload=new JButton("Upload Photo");
   JButton Submit=new JButton("Submit");


    LocalPage(){

        Name.setBounds(0,50,50,20);
        frame.add(Name);

        name.setBounds(50,50,200,20);
        frame.add(name);

        Address.setBounds(0,80,50,20);
        frame.add(Address);

        address.setBounds(70,80,300,20);
        frame.add(address);

        Marital.setBounds(0,110,80,20);
        frame.add(Marital);

        Single.setBounds(80,110,70,20);
        Single.setFocusable(false);
        frame.add(Single);

        Married.setBounds(150,110,70,20);
        Married.setFocusable(false);
        frame.add(Married);

        Gender.setBounds(0,140,50,20);
        frame.add(Gender);

        Male.setBounds(80,140,70,20);
        Male.setFocusable(false);
        frame.add(Male);

        Female.setBounds(150,140,80,20);
        Female.setFocusable(false);
        frame.add(Female);

        Age.setBounds(0,170,35,20);
        frame.add(Age);

        age.setBounds(50,170,40,20);
        frame.add(age);

        Skin.setBounds(150,170,80,20);
        frame.add(Skin);

        skin.setBounds(220,170,60,20);
        frame.add(skin);

        Height.setBounds(0,200,80,20);
        frame.add(Height);

        height.setBounds(80,200,40,20);
        frame.add(height);

        Last.setBounds(0,230,60,20);
        frame.add(Last);

        last.setBounds(80,230,200,20);
        frame.add(last);

        Relative.setBounds(0,260,100,20);
        frame.add(Relative);

        relative.setBounds(100,260,200,20);
        frame.add(relative);

        Contact.setBounds(0,290,170,20);
        frame.add(Contact);

        contact.setBounds(170,290,120,20);
        frame.add(contact);

        Upload.addActionListener(this);
        Upload.setBounds(150,340,170,30);
        frame.add(Upload);

        Submit.setBounds(300,400,100,30);
        frame.add(Submit);
        Submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });


        Enter.setBounds(0,0,500,35);
        Enter.setFont(new Font("Times New Roman",Font.BOLD,25));
        frame.add(Enter);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,800);
        frame.setLayout(null);
        frame.setVisible(true)

        ;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Upload){
            JFileChooser jFileChooser=new JFileChooser();
            jFileChooser.showOpenDialog(null);
        }

    }
}
